export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8081/api/v1',
  brandName: 'DERMO PRIME / VISIA'
};
